// ------------------------------------------------
// * Application: Vegan recipes app
// * Author: chanduthedev@gmail.com
// ------------------------------------------------

module.exports = {
  configuration: {
    host: "http://localhost",
    port: 7788,
    api: {
      user: {
        register: "/user/register",
        login: "/user/login",
        updateDetails: "/user/update",
        deteleUser: "/user/",
      },
      recipe: {
        register: "/recipe/create",
        read: "/recipe/view",
        update: "/recipe/update",
        detele: "/recipe/",
      },
    },
  },
};
